//
//  test1.h
//  test1
//
//  Created by Will Jessop on 1/22/20.
//  Copyright © 2020 Will Jessop. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for test1.
FOUNDATION_EXPORT double test1VersionNumber;

//! Project version string for test1.
FOUNDATION_EXPORT const unsigned char test1VersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <test1/PublicHeader.h>


