//
//  test1spnkr.h
//  test1spnkr
//
//  Created by Will Jessop on 1/22/20.
//  Copyright © 2020 Will Jessop. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for test1spnkr.
FOUNDATION_EXPORT double test1spnkrVersionNumber;

//! Project version string for test1spnkr.
FOUNDATION_EXPORT const unsigned char test1spnkrVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <test1spnkr/PublicHeader.h>


